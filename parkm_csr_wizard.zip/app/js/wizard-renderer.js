/**
 * ParkM CSR Wizard — Wizard Renderer
 * Renders header, entities, step checklist, and decision points.
 */
var WizardRenderer = (function () {
  // Track checked steps and decision selections
  var checkedSteps = {};
  var decisionSelections = {};

  /* ── localStorage persistence ─────────────────────────────────────── */

  function _storageKey() {
    var ticketId = (typeof ParkMApp !== "undefined" && ParkMApp.getTicketId)
      ? ParkMApp.getTicketId() : null;
    return ticketId ? "parkm_wizard_" + ticketId : null;
  }

  function _saveState() {
    var key = _storageKey();
    if (!key) return;
    try {
      localStorage.setItem(key, JSON.stringify({
        checkedSteps: checkedSteps,
        decisionSelections: decisionSelections
      }));
    } catch (e) { /* quota exceeded or unavailable */ }
  }

  function _loadState() {
    var key = _storageKey();
    if (!key) return;
    try {
      var saved = localStorage.getItem(key);
      if (saved) {
        var parsed = JSON.parse(saved);
        checkedSteps = parsed.checkedSteps || {};
        decisionSelections = parsed.decisionSelections || {};
      }
    } catch (e) { /* parse error */ }
  }

  /* ── Header Panel ─────────────────────────────────────────────────── */

  function renderHeader(wizard, customFields) {
    var intent = wizard.ai_intent || (customFields[ParkMConfig.FIELDS.AI_TAGS] || "").split(";")[0] || "unclear";
    var confidence = wizard.ai_confidence || customFields[ParkMConfig.FIELDS.AI_CONFIDENCE] || 0;
    var urgency = customFields[ParkMConfig.FIELDS.AI_URGENCY] || "medium";
    var complexity = customFields[ParkMConfig.FIELDS.AI_COMPLEXITY] || "moderate";
    var needsReview = wizard.requires_human_review ||
      customFields[ParkMConfig.FIELDS.REQUIRES_HUMAN_REVIEW] === "true";

    // Icon + label
    var iconEl = document.getElementById("intent-icon");
    var labelEl = document.getElementById("intent-label");
    iconEl.textContent = wizard.icon || "";
    labelEl.textContent = wizard.label || ParkMConfig.INTENT_LABELS[intent] || intent;

    // Confidence badge — handle both 0-1 and 0-100 ranges
    var confBadge = document.getElementById("confidence-badge");
    var confRaw = parseFloat(confidence) || 0;
    var confPct = confRaw > 1 ? Math.round(confRaw) : Math.round(confRaw * 100);
    confBadge.textContent = confPct + "% Confidence";
    if (confPct >= 85) {
      confBadge.style.background = "#e8f5e9";
      confBadge.style.color = "#27ae60";
    } else if (confPct >= 65) {
      confBadge.style.background = "#fff3e0";
      confBadge.style.color = "#e67e22";
    } else {
      confBadge.style.background = "#fdecea";
      confBadge.style.color = "#c0392b";
    }

    // Urgency badge
    var urgBadge = document.getElementById("urgency-badge");
    var urgStyle = ParkMConfig.URGENCY_STYLES[urgency] || ParkMConfig.URGENCY_STYLES.medium;
    urgBadge.textContent = urgStyle.label;
    urgBadge.style.background = urgStyle.bg;
    urgBadge.style.color = urgStyle.text;

    // Complexity badge
    var cmpBadge = document.getElementById("complexity-badge");
    var cmpStyle = ParkMConfig.COMPLEXITY_STYLES[complexity] || ParkMConfig.COMPLEXITY_STYLES.moderate;
    cmpBadge.textContent = complexity.charAt(0).toUpperCase() + complexity.slice(1);
    cmpBadge.style.background = cmpStyle.bg;
    cmpBadge.style.color = cmpStyle.text;

    // Human review banner
    var banner = document.getElementById("human-review-banner");
    banner.style.display = needsReview ? "block" : "none";

    // Intro text
    var introEl = document.getElementById("wizard-intro");
    introEl.textContent = wizard.intro || "";
  }

  /* ── Entity Panel ─────────────────────────────────────────────────── */

  function renderEntities(wizard) {
    var entities = wizard.extracted_entities || {};
    var panel = document.getElementById("entity-panel");
    var list = document.getElementById("entity-list");
    list.innerHTML = "";

    // Collect entity info from steps that have entity_field (deduplicate by field name)
    var seen = {};
    var entitySteps = (wizard.steps || []).filter(function (s) {
      if (!s.entity_field || seen[s.entity_field]) return false;
      seen[s.entity_field] = true;
      return true;
    });

    if (entitySteps.length === 0 && Object.keys(entities).length === 0) {
      panel.style.display = "none";
      return;
    }

    panel.style.display = "block";

    // Show extracted entities from steps
    entitySteps.forEach(function (step) {
      var card = document.createElement("div");
      card.className = "entity-card";

      var labelSpan = document.createElement("span");
      labelSpan.className = "entity-label";
      labelSpan.textContent = step.entity_field.replace(/_/g, " ");

      var rightDiv = document.createElement("div");

      if (step.entity_found && step.entity_value) {
        var valueSpan = document.createElement("span");
        valueSpan.className = "entity-value";
        valueSpan.textContent = step.entity_value;
        rightDiv.appendChild(valueSpan);
      } else {
        var missingSpan = document.createElement("span");
        missingSpan.className = "entity-value entity-value--missing";
        missingSpan.textContent = "Not found";
        rightDiv.appendChild(missingSpan);

        if (step.missing_action) {
          var btn = document.createElement("button");
          btn.className = "entity-action-btn";
          btn.textContent = step.missing_action.label || "Request";
          btn.setAttribute("data-template", step.missing_action.template);
          btn.addEventListener("click", function () {
            if (typeof TemplatePanel !== "undefined") {
              TemplatePanel.loadAndPreview(step.missing_action.template);
            }
          });
          rightDiv.appendChild(btn);
        }
      }

      card.appendChild(labelSpan);
      card.appendChild(rightDiv);
      list.appendChild(card);
    });
  }

  /* ── Step Checklist ───────────────────────────────────────────────── */

  function renderSteps(steps) {
    var container = document.getElementById("steps-list");
    container.innerHTML = "";
    checkedSteps = {};
    decisionSelections = {};
    _loadState();  // restore saved progress for this ticket

    (steps || []).forEach(function (step) {
      var row = document.createElement("div");
      row.className = "step-row";

      if (step.is_section_header) {
        renderSectionHeader(row, step);
      } else if (step.decision_point) {
        renderDecisionStep(row, step);
      } else {
        renderCheckboxStep(row, step);
      }

      // Interactive embedded UI (e.g., account lookup, refund evaluation)
      if (step.interactive) {
        var embedDiv = document.createElement("div");
        embedDiv.className = "step-interactive-embed";
        embedDiv.id = "interactive-" + step.id;
        embedDiv.setAttribute("data-interactive", step.interactive);
        row.appendChild(embedDiv);
      }

      // Conditional step: hidden until the matching decision is selected
      if (step.show_for_action) {
        row.setAttribute("data-show-for-action", step.show_for_action);
        row.setAttribute("data-decision-id", step.depends_on || "");
        row.style.display = "none";
        row.classList.add("conditional-step");
      }

      container.appendChild(row);
    });

    // Restore conditional step visibility from saved decisions
    _applyConditionalVisibility();
  }

  function _applyConditionalVisibility() {
    var container = document.getElementById("steps-list");
    if (!container) return;
    var conditionalRows = container.querySelectorAll(".conditional-step");
    for (var i = 0; i < conditionalRows.length; i++) {
      var row = conditionalRows[i];
      var action = row.getAttribute("data-show-for-action");
      var decisionId = row.getAttribute("data-decision-id");
      var selectedAction = decisionSelections[decisionId];
      if (selectedAction && selectedAction === action) {
        row.style.display = "";
      } else {
        row.style.display = "none";
      }
    }
  }

  function renderSectionHeader(row, step) {
    row.className = "step-row section-header";
    // Extract index from id "_section_0" → "0"
    var sectionIdx = step.id.replace("_section_", "");
    row.id = "section-header-" + sectionIdx;
    var header = document.createElement("div");
    header.className = "section-header-text";
    header.textContent = step.text;
    row.appendChild(header);
  }

  function renderCheckboxStep(row, step) {
    var main = document.createElement("div");
    main.className = "step-main";

    var checkbox = document.createElement("input");
    checkbox.type = "checkbox";
    checkbox.id = "step-" + step.id;
    checkbox.addEventListener("change", function () {
      checkedSteps[step.id] = this.checked;
      textSpan.className = this.checked ? "step-text checked" : "step-text";
      _saveState();
    });

    var textSpan = document.createElement("span");
    textSpan.className = "step-text";
    textSpan.textContent = step.text;

    // Restore saved state
    if (checkedSteps[step.id]) {
      checkbox.checked = true;
      textSpan.className = "step-text checked";
    }

    main.appendChild(checkbox);
    main.appendChild(textSpan);

    if (step.required) {
      var req = document.createElement("span");
      req.className = "step-required";
      req.textContent = "REQ";
      main.appendChild(req);
    }

    main.addEventListener("click", function (e) {
      if (e.target !== checkbox) {
        checkbox.checked = !checkbox.checked;
        checkbox.dispatchEvent(new Event("change"));
      }
    });

    row.appendChild(main);

    // Entity missing warning
    if (step.entity_field && !step.entity_found) {
      var warning = document.createElement("div");
      warning.className = "step-entity-warning";
      warning.innerHTML = "&#9888; " + step.entity_field.replace(/_/g, " ") + " not found in email";
      row.appendChild(warning);
    }

    // Email link button
    if (step.email_link) {
      var emailBtn = document.createElement("a");
      emailBtn.href = step.email_link;
      emailBtn.className = "step-email-link";
      emailBtn.textContent = step.email_link.replace("mailto:", "");
      emailBtn.target = "_blank";
      row.appendChild(emailBtn);
    }

    // V3: Suggestions list (bullet tips under a step)
    if (step.suggestions && step.suggestions.length > 0) {
      var sugList = document.createElement("ul");
      sugList.className = "step-suggestions";
      step.suggestions.forEach(function (sug) {
        var li = document.createElement("li");
        li.textContent = sug;
        sugList.appendChild(li);
      });
      row.appendChild(sugList);
    }

    // V3: Branches (conditional paths like Active/Cancelled, Yes/No)
    if (step.branches && step.branches.length > 0) {
      var branchContainer = document.createElement("div");
      branchContainer.className = "step-branches";
      step.branches.forEach(function (branch) {
        var branchDiv = document.createElement("div");
        branchDiv.className = "step-branch";

        var branchHeader = document.createElement("div");
        branchHeader.className = "step-branch-label";
        branchHeader.textContent = branch.label + ":";
        branchDiv.appendChild(branchHeader);

        if (branch.description) {
          var descDiv = document.createElement("div");
          descDiv.className = "step-branch-desc";
          descDiv.textContent = branch.description;
          branchDiv.appendChild(descDiv);
        }

        if (branch.suggestions && branch.suggestions.length > 0) {
          var bSugList = document.createElement("ul");
          bSugList.className = "step-suggestions";
          branch.suggestions.forEach(function (sug) {
            var li = document.createElement("li");
            li.textContent = sug;
            bSugList.appendChild(li);
          });
          branchDiv.appendChild(bSugList);
        }

        if (branch.email_link) {
          var bEmailBtn = document.createElement("a");
          bEmailBtn.href = branch.email_link;
          bEmailBtn.className = "step-email-link";
          bEmailBtn.textContent = branch.email_link.replace("mailto:", "");
          bEmailBtn.target = "_blank";
          branchDiv.appendChild(bEmailBtn);
        }

        branchContainer.appendChild(branchDiv);
      });
      row.appendChild(branchContainer);
    }

    // V3: Common causes list
    if (step.common_causes && step.common_causes.length > 0) {
      var causesDiv = document.createElement("div");
      causesDiv.className = "step-common-causes";
      var causesLabel = document.createElement("div");
      causesLabel.className = "step-common-causes-label";
      causesLabel.textContent = "Common causes:";
      causesDiv.appendChild(causesLabel);
      var causesList = document.createElement("ul");
      causesList.className = "step-suggestions";
      step.common_causes.forEach(function (cause) {
        var li = document.createElement("li");
        li.textContent = cause;
        causesList.appendChild(li);
      });
      causesDiv.appendChild(causesList);
      row.appendChild(causesDiv);
    }

    // V2: Substep (legacy — still supported for non-converted tags)
    if (step.substep) {
      var substepDiv = document.createElement("div");
      substepDiv.className = "step-substep";
      substepDiv.textContent = step.substep;
      substepDiv.id = "substep-" + step.id;

      var toggle = document.createElement("span");
      toggle.className = "step-toggle";
      toggle.textContent = "Show details";
      toggle.addEventListener("click", function () {
        var expanded = substepDiv.classList.toggle("expanded");
        toggle.textContent = expanded ? "Hide details" : "Show details";
      });

      row.appendChild(toggle);
      row.appendChild(substepDiv);
    }
  }

  function renderDecisionStep(row, step) {
    // Decision point header (no checkbox)
    var main = document.createElement("div");
    main.className = "step-main";
    main.style.cursor = "default";

    var textSpan = document.createElement("span");
    textSpan.className = "step-text";
    textSpan.style.marginLeft = "24px"; // align with checkbox steps
    textSpan.textContent = step.text;

    main.appendChild(textSpan);

    if (step.required) {
      var req = document.createElement("span");
      req.className = "step-required";
      req.textContent = "REQ";
      main.appendChild(req);
    }

    row.appendChild(main);

    // Substep text (if any)
    if (step.substep) {
      var substepDiv = document.createElement("div");
      substepDiv.className = "step-substep expanded";
      substepDiv.textContent = step.substep;
      row.appendChild(substepDiv);
    }

    // Decision buttons
    var btnGroup = document.createElement("div");
    btnGroup.className = "decision-buttons";

    (step.options || []).forEach(function (option) {
      var btn = document.createElement("button");
      btn.className = "decision-btn";
      btn.textContent = option.label;
      btn.setAttribute("data-action", option.action || "");

      btn.addEventListener("click", function () {
        // Mark this step as completed with the selected decision
        decisionSelections[step.id] = option.action;
        checkedSteps[step.id] = true;

        // Update button states
        var siblings = btnGroup.querySelectorAll(".decision-btn");
        for (var i = 0; i < siblings.length; i++) {
          siblings[i].classList.remove("selected");
          siblings[i].classList.add("dimmed");
        }
        btn.classList.add("selected");
        btn.classList.remove("dimmed");

        _saveState();
        _applyConditionalVisibility();

        // If option has a next_template, preview it
        if (option.next_template && typeof TemplatePanel !== "undefined") {
          TemplatePanel.loadAndPreview(option.next_template);
        }

        // If option has redirect_wizard, notify the app
        if (option.redirect_wizard && typeof ParkMApp !== "undefined" && ParkMApp.onRedirectWizard) {
          ParkMApp.onRedirectWizard(option.redirect_wizard);
        }
      });

      btnGroup.appendChild(btn);
    });

    // Restore saved decision selection
    var savedAction = decisionSelections[step.id];
    if (savedAction) {
      var allBtns = btnGroup.querySelectorAll(".decision-btn");
      for (var j = 0; j < allBtns.length; j++) {
        if (allBtns[j].getAttribute("data-action") === savedAction) {
          allBtns[j].classList.add("selected");
        } else {
          allBtns[j].classList.add("dimmed");
        }
      }
    }

    row.appendChild(btnGroup);
  }

  /* ── Public API ───────────────────────────────────────────────────── */

  return {
    renderHeader: renderHeader,
    renderEntities: renderEntities,
    renderSteps: renderSteps,

    /** Get map of step id → checked boolean */
    getCheckedSteps: function () {
      return Object.assign({}, checkedSteps);
    },

    /** Get map of step id → selected action for decision points */
    getDecisionSelections: function () {
      return Object.assign({}, decisionSelections);
    },

    /** Check if all required steps are completed */
    allRequiredComplete: function (steps) {
      return (steps || []).every(function (step) {
        if (!step.required) return true;
        return !!checkedSteps[step.id];
      });
    }
  };
})();
